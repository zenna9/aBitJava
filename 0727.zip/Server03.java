import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server03 {
    public static void main(String[] args) throws IOException {
        ServerSocket ss = new ServerSocket(9999);
        while(true) {
            // 연결 부분
            Socket cs = ss.accept();
            System.out.println("client IP : " + cs.getInetAddress());
            System.out.println("client Port : " + cs.getPort());

            // 데이터 수신 부분
            InputStream is = cs.getInputStream();
            DataInputStream dis = new DataInputStream(is);
            String message = dis.readUTF();

            // 데이터 전송 부분
            OutputStream os = cs.getOutputStream();
            DataOutputStream dos = new DataOutputStream(os);
            dos.writeUTF("echo " + message);

            // 연결 해제 부분
            dos.close();
            cs.close();
        }
    }
}
