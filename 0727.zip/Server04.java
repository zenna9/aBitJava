import com.sun.source.tree.Scope;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

class Sender extends Thread {
    Socket cs;

    Sender(Socket cs) {
        this.cs = cs;
    }

    public void run() {
        try {
            OutputStream os = cs.getOutputStream();
            DataOutputStream dos = new DataOutputStream(os);
            Scanner sc = new Scanner(System.in);
            while(dos != null) {
                String message = sc.nextLine();
                dos.writeUTF("["+cs.getLocalAddress()+":"+cs.getLocalPort()+"] "+message);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}


class Receiver extends Thread {
    Socket cs;

    Receiver(Socket cs) {
        this.cs = cs;
    }

    public void run() {
        try {
            InputStream is = cs.getInputStream();
            DataInputStream dis = new DataInputStream(is);
            while (dis != null) {
                System.out.println(dis.readUTF());
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}

public class Server04 {
    public static void main(String[] args) throws IOException {
        ServerSocket ss = new ServerSocket(9999);
        System.out.println("Server Started...");

        Socket cs = ss.accept();

        // 수신 부분
        Receiver receiver = new Receiver(cs);
        receiver.start();

        // 전송 부분
        Sender sender = new Sender(cs);
        sender.start();
    }
}
