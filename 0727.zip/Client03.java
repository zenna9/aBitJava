import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client03 {
    public static void main(String[] args) throws IOException {
        // 연결 부분
        Socket cs = new Socket("192.168.1.36", 9999);

        // 데이터 전송 부분
        Scanner sc = new Scanner(System.in);
        String message = sc.nextLine();
        OutputStream os = cs.getOutputStream();
        DataOutputStream dos = new DataOutputStream(os);
        dos.writeUTF(message);

        // 데이터 수신 부분
        InputStream is = cs.getInputStream();
        DataInputStream dis = new DataInputStream(is);
        System.out.println(dis.readUTF());

        // 연결 해제 부분
        dis.close();
        cs.close();
    }
}
