
class Ex2_1 extends Thread {
    public void run() {
        try {
            throw new Exception();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}

public class Ex02 {
    public static void main(String[] args) {
        Ex2_1 t1 = new Ex2_1();
        t1.start();
    }
}
