public class Ex03 {
    public static void main(String[] args) {
        long start = System.currentTimeMillis();

        for(int i = 0; i<10000; i++) {
            System.out.printf("%s", "-");
        }

        System.out.println("time1 : "+ (System.currentTimeMillis() - start));

        for(int i = 0; i<10000; i++) {
            System.out.printf("%s", "|");
        }

        System.out.println("time2 : "+ (System.currentTimeMillis() - start));
    }
}
