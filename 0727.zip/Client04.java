import java.io.IOException;
import java.net.ConnectException;
import java.net.Socket;

public class Client04 {
    public static void main(String[] args) throws IOException {
        Socket cs = new Socket("192.168.1.36", 9999);

        Sender sender = new Sender(cs);
        sender.start();

        Receiver receiver = new Receiver(cs);
        receiver.start();
    }
}
