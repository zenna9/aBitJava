

class Ex1_1 extends Thread {
    public void run() {
        for(int i=0; i< 1000; i++) {
            System.out.println("Ex1_1 : " + i);
        }
    }
}

class Ex1_2 implements Runnable {
    public void run() {
        for(int i=0; i< 1000; i++) {
            System.out.println("Ex1_2 : " + i);
        }
    }
}

public class Ex01 {
    public static void main(String[] args) {
        Ex1_1 t1 = new Ex1_1();

        t1.start();

        Runnable r = new Ex1_2();
        Thread t2 = new Thread(r);

        t2.start();

        for(int i=0; i< 1000; i++) {
            System.out.println("main : " + i);
        }
    }
}
