class Ex04_1 extends Thread {
    public void run() {
        for(int i = 0; i<10000; i++) {
            System.out.printf("%s", "-");
        }
        System.out.println("time1 : "+ (System.currentTimeMillis() - Ex04.start));
    }
}
public class Ex04 {
    static long start = 0;
    public static void main(String[] args) {
        start = System.currentTimeMillis();
        Ex04_1 t1 = new Ex04_1();
        t1.start();
        for(int i = 0; i<10000; i++) {
            System.out.printf("%s", "|");
        }
        System.out.println("time2 : "+ (System.currentTimeMillis() - Ex04.start));
    }
}
