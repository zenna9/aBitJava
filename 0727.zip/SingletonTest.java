
class SingletonThread implements Runnable {
    public void run() {
        System.out.println(Singleton.getInstance());
    }
}

public class SingletonTest {
    public static void main(String[] args) {
        for(int i=0; i<10; i++) {
            Thread singletonThread = new Thread(new SingletonThread());
            singletonThread.start();
        }
    }
}
