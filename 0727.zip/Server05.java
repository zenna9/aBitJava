import javax.xml.crypto.Data;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

class ServerReceiver extends Thread {
    Socket cs;

    ServerReceiver(Socket cs) {
        this.cs = cs;
    }

    void sendToAll(String message) {
        try {
            for (Socket client : Server05.socketList) {
                if (client == cs) continue;
                OutputStream os = null;
                os = client.getOutputStream();
                DataOutputStream dos = new DataOutputStream(os);
                dos.writeUTF(message);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void run() {
        try {
            InputStream is = cs.getInputStream();
            DataInputStream dis = new DataInputStream(is);
            while (dis != null) {
                String message = dis.readUTF();
                sendToAll(message);
            }
        } catch (SocketException e) {
            Server05.socketList.remove(cs);
            sendToAll("[" + cs.getInetAddress() + ":" + cs.getPort() + "] was left");
            System.out.println("[" + cs.getInetAddress() + ":" + cs.getPort() + "] was left");
            System.out.println("clients : " + Server05.socketList.size());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}

public class Server05 {
    static List<Socket> socketList;

    public static void main(String[] args) throws IOException {
        socketList = new ArrayList<>();
        ServerSocket ss = new ServerSocket(9999);
        System.out.println("Server Started...");
        while (true) {
            Socket cs = ss.accept();
            socketList.add(cs);
            System.out.println("[" + cs.getInetAddress() + ":" + cs.getPort() + "] was conneted");
            System.out.println("clients : " + socketList.size());
            ServerReceiver sr = new ServerReceiver(cs);
            sr.start();
        }
    }
}
